-- ============================================
-- DAYA DATABASE SCHEMA
-- Run this in Supabase SQL Editor
-- ============================================

-- Users profile (extends Supabase auth.users)
create table public.profiles (
  id            uuid references auth.users(id) on delete cascade primary key,
  name          text,
  wake_time     text default '7:00 am',
  work_style    text default 'deep',
  ai_consent    boolean default false,
  streak        integer default 0,
  last_plan_date date,
  created_at    timestamptz default now()
);

-- Day plans
create table public.day_plans (
  id            uuid default gen_random_uuid() primary key,
  user_id       uuid references public.profiles(id) on delete cascade,
  brain_dump    text not null,
  greeting      text,
  tip           text,
  planned_for   date default current_date,
  created_at    timestamptz default now()
);

-- Tasks within a day plan
create table public.tasks (
  id            uuid default gen_random_uuid() primary key,
  plan_id       uuid references public.day_plans(id) on delete cascade,
  user_id       uuid references public.profiles(id) on delete cascade,
  title         text not null,
  time_slot     text,
  duration      integer default 30,
  category      text default 'work',
  priority      text default 'medium',
  emoji         text default '✦',
  completed     boolean default false,
  sort_order    integer default 0,
  created_at    timestamptz default now()
);

-- ============================================
-- ROW LEVEL SECURITY — users see only their data
-- ============================================

alter table public.profiles  enable row level security;
alter table public.day_plans enable row level security;
alter table public.tasks     enable row level security;

-- Profiles: own row only
create policy "profiles: own row" on public.profiles
  for all using (auth.uid() = id);

-- Day plans: own rows only
create policy "day_plans: own rows" on public.day_plans
  for all using (auth.uid() = user_id);

-- Tasks: own rows only
create policy "tasks: own rows" on public.tasks
  for all using (auth.uid() = user_id);

-- ============================================
-- Auto-create profile on sign-up
-- ============================================

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id)
  values (new.id);
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
