import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useFonts, DMSerifDisplay_400Regular } from '@expo-google-fonts/dm-serif-display';
import { DMSans_400Regular, DMSans_500Medium, DMSans_700Bold } from '@expo-google-fonts/dm-sans';
import { View, ActivityIndicator } from 'react-native';
import { colors } from './src/theme';
import { AuthProvider, useAuth } from './src/context/AuthContext';
import SplashScreen        from './src/screens/SplashScreen';
import AuthScreen          from './src/screens/AuthScreen';
import OnboardingScreen    from './src/screens/OnboardingScreen';
import AIConsentScreen     from './src/screens/AIConsentScreen';
import BrainDumpScreen     from './src/screens/BrainDumpScreen';
import DayPlanScreen       from './src/screens/DayPlanScreen';
import SettingsScreen      from './src/screens/SettingsScreen';
import PaywallScreen       from './src/screens/PaywallScreen';
import PrivacyPolicyScreen from './src/screens/PrivacyPolicyScreen';

const Stack = createNativeStackNavigator();

function RootNavigator() {
  const { session, profile, loading } = useAuth();
  if (loading) return (
    <View style={{ flex:1, alignItems:'center', justifyContent:'center', backgroundColor: colors.primary }}>
      <ActivityIndicator color={colors.white} size="large" />
    </View>
  );
  const initialRoute = !session ? 'Splash' : !profile?.name ? 'Onboarding' : !profile?.ai_consent ? 'AIConsent' : 'BrainDump';
  return (
    <Stack.Navigator initialRouteName={initialRoute} screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Splash"        component={SplashScreen}        options={{ animation: 'none' }} />
      <Stack.Screen name="Auth"          component={AuthScreen}          options={{ animation: 'fade' }} />
      <Stack.Screen name="Onboarding"    component={OnboardingScreen}    options={{ animation: 'fade' }} />
      <Stack.Screen name="AIConsent"     component={AIConsentScreen}     options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="BrainDump"     component={BrainDumpScreen}     options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="DayPlan"       component={DayPlanScreen}       options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="Settings"      component={SettingsScreen}      options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="Paywall"       component={PaywallScreen}       options={{ animation: 'slide_from_bottom' }} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicyScreen} options={{ animation: 'slide_from_right' }} />
    </Stack.Navigator>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({ DMSerifDisplay_400Regular, DMSans_400Regular, DMSans_500Medium, DMSans_700Bold });
  if (!fontsLoaded) return (
    <View style={{ flex:1, alignItems:'center', justifyContent:'center', backgroundColor: colors.primary }}>
      <ActivityIndicator color={colors.white} size="large" />
    </View>
  );
  return (
    <AuthProvider>
      <NavigationContainer>
        <RootNavigator />
      </NavigationContainer>
    </AuthProvider>
  );
}
