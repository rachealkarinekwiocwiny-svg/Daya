import { supabase } from '../lib/supabase';

// ── DAY PLANS ──────────────────────────────────────────────

export async function saveDayPlan({ userId, brainDump, greeting, tip, tasks }) {
  // 1. Insert the plan
  const { data: plan, error: planError } = await supabase
    .from('day_plans')
    .insert({ user_id: userId, brain_dump: brainDump, greeting, tip })
    .select()
    .single();

  if (planError) return { error: planError };

  // 2. Insert all tasks linked to this plan
  if (tasks?.length > 0) {
    const taskRows = tasks.map((t, i) => ({
      plan_id:    plan.id,
      user_id:    userId,
      title:      t.title,
      time_slot:  t.time,
      duration:   t.duration,
      category:   t.category,
      priority:   t.priority,
      emoji:      t.emoji,
      sort_order: i,
    }));

    const { error: tasksError } = await supabase.from('tasks').insert(taskRows);
    if (tasksError) return { error: tasksError };
  }

  // 3. Update streak
  await updateStreak(userId);

  return { data: plan };
}

export async function getTodaysPlan(userId) {
  const today = new Date().toISOString().split('T')[0];

  const { data: plan, error } = await supabase
    .from('day_plans')
    .select('*, tasks(*)')
    .eq('user_id', userId)
    .eq('planned_for', today)
    .order('created_at', { ascending: false })
    .limit(1)
    .single();

  return { data: plan, error };
}

export async function getPlanHistory(userId, limit = 10) {
  const { data, error } = await supabase
    .from('day_plans')
    .select('id, planned_for, greeting, created_at')
    .eq('user_id', userId)
    .order('planned_for', { ascending: false })
    .limit(limit);

  return { data, error };
}

// ── TASKS ──────────────────────────────────────────────────

export async function toggleTask(taskId, completed) {
  const { data, error } = await supabase
    .from('tasks')
    .update({ completed })
    .eq('id', taskId)
    .select()
    .single();

  return { data, error };
}

export async function updateTaskOrder(tasks) {
  const updates = tasks.map((t, i) =>
    supabase.from('tasks').update({ sort_order: i }).eq('id', t.id)
  );
  await Promise.all(updates);
}

// ── STREAK ────────────────────────────────────────────────

async function updateStreak(userId) {
  const { data: profile } = await supabase
    .from('profiles')
    .select('streak, last_plan_date')
    .eq('id', userId)
    .single();

  if (!profile) return;

  const today     = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  let newStreak = 1;
  if (profile.last_plan_date === yesterday) {
    newStreak = (profile.streak || 0) + 1;  // consecutive day
  } else if (profile.last_plan_date === today) {
    newStreak = profile.streak;              // already planned today
  }

  await supabase
    .from('profiles')
    .update({ streak: newStreak, last_plan_date: today })
    .eq('id', userId);
}

// ── PROFILE ───────────────────────────────────────────────

export async function updateProfile(userId, updates) {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .single();

  return { data, error };
}
