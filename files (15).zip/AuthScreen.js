import React, { useRef, useEffect, useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, Animated, KeyboardAvoidingView,
  Platform, ScrollView, StatusBar, ActivityIndicator,
} from 'react-native';
import { colors, fonts, spacing, radius, shadow } from '../theme';
import { useAuth } from '../context/AuthContext';
import BloomLogo from '../components/BloomLogo';

export default function AuthScreen({ navigation }) {
  const { signInWithEmail, signUpWithEmail } = useAuth();

  const [mode, setMode]       = useState('signin'); // 'signin' | 'signup'
  const [email, setEmail]     = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const fadeAnim  = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim,  { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 65, friction: 9, useNativeDriver: true }),
    ]).start();
  }, []);

  const handleSubmit = async () => {
    setError('');
    if (!email.trim() || !password.trim()) {
      setError('Please enter your email and password.');
      return;
    }
    setLoading(true);
    try {
      const fn = mode === 'signin' ? signInWithEmail : signUpWithEmail;
      const { error } = await fn(email.trim(), password);
      if (error) setError(error.message);
      // On success AuthContext triggers navigation via session change
    } catch (e) {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.blob1} />
      <View style={styles.blob2} />

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">

          <Animated.View style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}>

            {/* Logo */}
            <View style={styles.logoWrap}>
              <View style={styles.logoBg}>
                <BloomLogo size={36} />
              </View>
              <Text style={styles.brandName}>daya</Text>
              <Text style={styles.brandSub}>your day, beautifully planned</Text>
            </View>

            {/* Card */}
            <View style={[styles.card, shadow.lg]}>
              <Text style={styles.title}>
                {mode === 'signin' ? 'Welcome back' : 'Create account'}
              </Text>

              {/* Apple Sign In placeholder */}
              <TouchableOpacity style={[styles.appleBtn, shadow.sm]} activeOpacity={0.85}>
                <Text style={styles.appleBtnText}>  Continue with Apple</Text>
              </TouchableOpacity>

              <View style={styles.dividerRow}>
                <View style={styles.dividerLine} />
                <Text style={styles.dividerText}>or</Text>
                <View style={styles.dividerLine} />
              </View>

              {/* Email */}
              <TextInput
                style={styles.input}
                placeholder="Email address"
                placeholderTextColor={colors.grayLight}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />

              {/* Password */}
              <TextInput
                style={[styles.input, { marginTop: spacing.sm }]}
                placeholder="Password"
                placeholderTextColor={colors.grayLight}
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                returnKeyType="done"
                onSubmitEditing={handleSubmit}
              />

              {/* Error */}
              {error ? <Text style={styles.errorText}>{error}</Text> : null}

              {/* Submit */}
              <TouchableOpacity
                style={[styles.btn, loading && styles.btnDisabled]}
                onPress={handleSubmit}
                disabled={loading}
                activeOpacity={0.85}
              >
                {loading
                  ? <ActivityIndicator color={colors.white} />
                  : <Text style={styles.btnText}>{mode === 'signin' ? 'Sign in' : 'Create account'}</Text>
                }
              </TouchableOpacity>

              {/* Toggle mode */}
              <TouchableOpacity
                style={styles.toggleBtn}
                onPress={() => { setMode(m => m === 'signin' ? 'signup' : 'signin'); setError(''); }}
              >
                <Text style={styles.toggleText}>
                  {mode === 'signin'
                    ? "Don't have an account? Sign up"
                    : 'Already have an account? Sign in'}
                </Text>
              </TouchableOpacity>
            </View>

            {/* Legal */}
            <Text style={styles.legal}>
              By continuing you agree to our Terms of Use and Privacy Policy.
            </Text>

          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex:      { flex: 1 },
  container: { flex: 1, backgroundColor: colors.offWhite },
  scroll:    { flexGrow: 1, paddingHorizontal: spacing.lg, paddingTop: 60, paddingBottom: 40 },

  blob1: {
    position: 'absolute', top: -80, right: -60,
    width: 240, height: 240, borderRadius: 120,
    backgroundColor: colors.lightMid, opacity: 0.5,
  },
  blob2: {
    position: 'absolute', bottom: 60, left: -80,
    width: 200, height: 200, borderRadius: 100,
    backgroundColor: colors.light, opacity: 0.6,
  },

  logoWrap:  { alignItems: 'center', marginBottom: spacing.xl, gap: 8 },
  logoBg: {
    width: 72, height: 72, borderRadius: 20,
    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center',
    ...shadow.md,
  },
  brandName: { fontSize: 26, fontFamily: fonts.display, color: colors.dark, letterSpacing: 2 },
  brandSub:  { fontSize: 13, fontFamily: fonts.sans, color: colors.grayLight },

  card: {
    backgroundColor: colors.white, borderRadius: radius.xl, padding: spacing.xl,
  },
  title: { fontSize: 24, fontFamily: fonts.display, color: colors.dark, marginBottom: spacing.lg },

  appleBtn: {
    backgroundColor: colors.dark, borderRadius: radius.md,
    paddingVertical: 14, alignItems: 'center', marginBottom: spacing.md,
  },
  appleBtnText: { fontSize: 15, fontFamily: fonts.sansMed, color: colors.white },

  dividerRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: spacing.md },
  dividerLine: { flex: 1, height: 0.5, backgroundColor: colors.grayFaint },
  dividerText: { fontSize: 12, fontFamily: fonts.sans, color: colors.grayLight },

  input: {
    borderWidth: 1.5, borderColor: colors.grayFaint, borderRadius: radius.md,
    paddingHorizontal: spacing.md, paddingVertical: 13,
    fontSize: 16, fontFamily: fonts.sans, color: colors.dark,
    backgroundColor: colors.offWhite,
  },

  errorText: {
    fontSize: 13, fontFamily: fonts.sans, color: colors.error,
    marginTop: spacing.sm, textAlign: 'center',
  },

  btn: {
    backgroundColor: colors.primary, borderRadius: radius.md,
    paddingVertical: 15, alignItems: 'center',
    marginTop: spacing.md, ...shadow.sm,
  },
  btnDisabled: { opacity: 0.5 },
  btnText:     { fontSize: 16, fontFamily: fonts.sansBold, color: colors.white },

  toggleBtn:  { paddingVertical: spacing.md, alignItems: 'center' },
  toggleText: { fontSize: 13, fontFamily: fonts.sansMed, color: colors.primary },

  legal: {
    fontSize: 11, fontFamily: fonts.sans, color: colors.grayLight,
    textAlign: 'center', marginTop: spacing.lg, lineHeight: 17,
  },
});
